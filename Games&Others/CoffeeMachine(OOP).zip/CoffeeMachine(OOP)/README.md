This program behaves like a vending coffee machine to get coffee orders (coffee maker) and 
their payments (money machine). Object Oriented Programming (OOP) concept is used here 
and separate files are created for different classes.