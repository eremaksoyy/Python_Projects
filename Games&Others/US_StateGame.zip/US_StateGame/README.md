This US State Game aims users to enter the name of the states by clicking any state on the map displayed. To check 
the correctness of any state entered, '50_states.csv' file, which has the name of the states along with their coordinates 
in the map, will be used. To make the game more educational, a new file called 'states_to_learn' will be created to record 
the names of the states that are not entered or entered wrong until the end of the game. As the file will be updated after 
every entry, user can check the file and end the game anytime if they do not want to continue till the end. 
Time, Turtle and Pandas are used.