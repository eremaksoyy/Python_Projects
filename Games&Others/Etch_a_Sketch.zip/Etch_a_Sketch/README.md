This mini project works with user's input where user can use “w”, “s”, “a” and “d” letters on the keyboard to direction the pen, and “c” letter to 
clean the board. It is defined how many units the pen will be moved in each pick of letters so it can be changed by 
changing the value in the methods forward(), backward(), and left(). The Turtle library is used here.