import cv2
import os
import glob

# Change the file path according to the path of the videos saved 

for video_file_path in glob.glob("D:\eremaksoyy\PROGRAMMING\Python\Veri Etiketleme - TT\labelImg-master\Videos\*"):
    file_name = os.path.basename(video_file_path).split(".")[0]

    if (not os.path.exists(f"D:\eremaksoyy\PROGRAMMING\Python\Veri Etiketleme - TT\labelImg-master\Images\{file_name}")):
        os.makedirs(f"D:\eremaksoyy\PROGRAMMING\Python\Veri Etiketleme - TT\labelImg-master\Images\{file_name}")
        video_cap = cv2.VideoCapture(video_file_path)
        success, image = video_cap.read()
        count = 0
        while success:
            cv2.imwrite(f"D:\eremaksoyy\PROGRAMMING\Python\Veri Etiketleme - TT\labelImg-master\Images\{file_name}\{file_name}_%d.png" % count,
                        image)  # save frame as JPEG file      
            success, image = video_cap.read()
            print('Read a new frame: ', success)
            count += 1
            
            