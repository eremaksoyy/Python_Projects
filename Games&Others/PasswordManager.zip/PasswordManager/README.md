This Password Manager project helps the user to create a strong password for the websites they want to use and saves 
their email address/username for the website with their password generated. When user wants to use that particular 
website again, they can easily select the saved option and the necessary fields to use that particular website will be filled 
automatically. Random, Tkinter and json are used.