import socket
from tkinter import *
from tkinter import messagebox


class LoginScreen(Frame):
    def __init__(self, client):
        Frame.__init__(self)
        self.client = client
        self.pack()
        self.master.title("Login")

        self.frame1 = Frame(self)
        self.frame1.pack(padx=5, pady=5)

        self.usernamelable = Label(self.frame1, text="User Name:")
        self.usernamelable.pack(side=LEFT, pady=5, padx=5)

        self.username = Entry(self.frame1, name="username")
        self.username.pack(side=LEFT, padx=5, pady=5)

        self.frame2 = Frame(self)
        self.frame2.pack(padx=5, pady=5)

        self.passwordLabel = Label(self.frame2, text="Password")
        self.passwordLabel.pack(side=LEFT, padx=5, pady=5)

        self.password = Entry(self.frame2, name="password", show="*")
        self.password.pack(side=LEFT, padx=5, pady=5)

        self.frame3 = Frame(self)
        self.frame3.pack(padx=5, pady=5)

        self.login = Button(self.frame3, text="Login", command=self.buttonPressed)
        self.login.pack(side=LEFT, padx=5, pady=5)

    def buttonPressed(self):
        username = self.username.get()
        password = self.password.get()

        clientMsg = "login;" + username + ";" + password

        self.client.send(clientMsg.encode())
        serverMsg = self.client.recv(1024).decode()

        if serverMsg == "login successful":
            self.client.send(clientMsg.encode())
            serverMsg = self.client.recv(1024).decode()
            reply = serverMsg
            list = reply.split(';')
            username = list[0]
            role = list[1]

            if 'barista' in role:
                  barista = Barista(self.client, username)
                  barista.mainloop()
            elif role == 'manager':
                  managerPage = Manager(self.client, username)
                  managerPage.mainloop()
            else:
                   print("Error: Unknown role")

        elif serverMsg == "login failed":
            messagebox.showerror("Message", "Invalid Login information")
            self.client.close()
            self.master.destroy()


class Barista(Frame):
    def __init__(self, client, username):
        Frame.__init__(self)
        self.client = client
        self.username = username
        self.pack()
        self.master.title("Barista Panel")
        frames = []
        self.frame1 = Frame(self)
        self.coffelabel = Label(self.frame1, text="COFFEE")
        self.coffelabel.pack(padx=5, pady=5)
        self.frame1.pack(padx=5, pady=5, anchor="w")
        frames.append(self.frame1)
        self.frame2 = Frame(self)
        self.frame2.pack(padx=5, pady=5, anchor="w")
        frames.append(self.frame2)
        self.frame3 = Frame(self)
        self.frame3.pack(padx=5, pady=5, anchor="w")
        frames.append(self.frame3)
        self.frame4 = Frame(self)
        self.frame4.pack(padx=5, pady=5, anchor="w")
        frames.append(self.frame4)
        self.frame5 = Frame(self)
        self.frame5.pack(padx=5, pady=5, anchor="w")
        frames.append(self.frame4)
        self.coffees = [("Latte", BooleanVar()), ("Cappuccino", BooleanVar()),
                        ("Americano", BooleanVar()),
                        ("Expresso", BooleanVar())]
        self.mainEntry = []
        counter = 0
        for coffee in self.coffees:
            self.coffeeSelection = Checkbutton(frames[counter], text=coffee[0], variable=coffee[1])
            self.coffeeSelection.pack(side=LEFT)
            self.mainEntry.append(Entry(frames[counter], justify=LEFT))
            self.mainEntry[counter].pack(padx=(30 - len(coffee[0])), side=RIGHT, anchor=E)
            counter += 1

        frames = []
        self.frame6 = Frame(self)
        self.frame6.pack(padx=5, pady=5)
        self.cakeslabel = Label(self.frame6, text="CAKES")
        self.cakeslabel.pack(padx=5, pady=5)

        frames.append(self.frame6)
        self.frame7 = Frame(self)
        self.frame7.pack(padx=5, pady=5, anchor="w")
        frames.append(self.frame7)
        self.frame8 = Frame(self)
        self.frame8.pack(padx=5, pady=5, anchor="w")
        frames.append(self.frame8)
        self.frame9 = Frame(self)
        self.frame9.pack(padx=5, pady=5, anchor="w")
        frames.append(self.frame9)
        self.frame10 = Frame(self)
        self.frame10.pack(padx=5, pady=5, anchor="w")
        frames.append(self.frame10)
        self.frame11 = Frame(self)
        self.frame11.pack(padx=5, pady=5, anchor="w")
        frames.append(self.frame11)
        self.cakes = [("San Sebastian", BooleanVar()), ("Mosaic", BooleanVar()),
                      ("Carrot", BooleanVar())]
        counter1 = 0
        for cake in self.cakes:
            self.cakeSelection = Checkbutton(frames[counter1], text=cake[0], variable=cake[1])
            self.cakeSelection.pack(side=LEFT)
            self.mainEntry.append(Entry(frames[counter1], justify=LEFT))
            self.mainEntry[counter].pack(padx=5, side=RIGHT)
            counter += 1
            counter1 += 1
        print(counter, counter1)
        self.discountlabel = Label(self.frame10, text="Discount code, if any:")
        self.discountlabel.pack(pady=5, padx=5, side=LEFT)
        self.mainEntry.append(Entry(self.frame10, justify=LEFT))
        self.mainEntry[counter].pack(padx=15, side=RIGHT)
        self.button = Button(self.frame11, text="Create", command=self.create_buttonPressed)
        self.button.pack(padx=5, pady=5, side=LEFT)
        self.button = Button(self.frame11, text="Close")  # , command=self.close_buttonPressed)
        self.button.pack(padx=5, pady=5, side=LEFT)

    def create_buttonPressed(self):
        order = ""
        counter = 0
        for coffee in self.coffees:
            if coffee[1].get():
                order += coffee[0] + "-" + str(self.mainEntry[counter].get()) + ";"
            counter += 1
        for cake in self.cakes:
            if cake[1].get():
                order += cake[0] + "-" + str(self.mainEntry[counter].get()) + ";"
                counter += 1
        if len(self.mainEntry[7].get()) == 0:
            self.client.send(("order;" + "nodiscountcode;" + self.username + ";" + order.lower().replace(" ", "")).encode())
        else:
            self.client.send(
                ("order;" + str(self.mainEntry[7].get()) + ";" + self.username + ";" + order.lower().replace(" ", "")).encode())


    def close_buttonPressed(self):
        self.socket.close()
        exit(1)


class Manager(Frame):
    def __init__(self, client, username):
        Frame.__init__(self)
        self.client = client
        self.username = username

        self.pack()
        self.master.title("Manager Panel")

        self.frame1 = Frame()
        self.reportLabel = Label(self.frame1, text="REPORTS")
        self.reportLabel.pack(padx=5, pady=5)
        self.frame1.pack(padx=5, pady=5)

        self.Manager_Actions_List = ["(1) What is most popular coffee overall? ",
                                     "(2) Which Barista has the highest number of orders?",
                                     "(3) What is the most popular product for the orders with discount code?",
                                     "(4) What is the most popular cake that is bought with expresso?"]

        self.Manager_select = StringVar()
        self.Manager_select.set(self.Manager_Actions_List[0])

        for select in self.Manager_select:
            radio = Radiobutton(self.frame1, text=select, variable=self.Manager_select, value=select)
            radio.pack(padx=5, pady=5)

        self.frame2 = Frame()
        self.frame2.pack(padx=5, pady=5, side=BOTTOM)
        self.Create = Button(self.frame2, text="Create", command=self.Create)
        self.Create.pack(side=LEFT, padx=5, pady=5)

        self.closeButtton = Button(self.frame2, text="Close", command=self.Close)
        self.closeButtton.pack(side=LEFT, padx=5, pady=5)

    def Close(self, none):
        self.client.close()
        exit(1)


    def Create(self):
        if self.Manager_select == self.Manager_select[0]:
            self.client.send("report1".encode())

        elif self.Manager_select == self.Manager_select[1]:
            self.client.send("report2".encode())

        elif self.Manager_select == self.Manager_select[2]:
            self.client.send("report3".encode())

        else:
            self.client.send("report4".encode())

        serverReply = self.client.recv(1024).decode()
        serverReply.split(";")

        message = ""
        for i in range(1, len(serverReply)):
            message += (serverReply[i] + "\n")
        messagebox.showinfo(serverReply[0], message)


if __name__ == "__main__":
    SERVER = "127.0.0.1"
    PORT = 5000

    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # create a socket object
    client.connect((SERVER, PORT))

    while True:
        connection_status = client.recv(1024).decode()
        if connection_status == "connection successful":
            loginScreen = LoginScreen(client)
            loginScreen.mainloop()
        elif connection_status == "connection failed":
            break
    client.close()
