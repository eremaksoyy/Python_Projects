This program is a coffee shop system that has Barista and Manager as classes and uses
multithreading and parallel programming concepts to read files for orders of users, prices
and the available discount codes if there is any. Tkinter is also used for users to enter parameters
and for visual purposes as well.