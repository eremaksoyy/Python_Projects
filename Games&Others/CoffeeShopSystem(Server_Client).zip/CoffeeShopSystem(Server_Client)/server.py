import socket
import threading

class ClientThread(threading.Thread):
    def __init__(self, clientsocket, clientaddress):
        threading.Thread.__init__(self)
        self.clientSocket = clientsocket
        self.clientAddress = clientaddress
        print("Connection from ", clientaddress)


    def run(self):
        serverMsg = "connection successful".encode()
        self.clientSocket.send(serverMsg)
        clientMsg = self.clientSocket.recv(1024).decode()
        result = check_login(clientMsg)
        serverMsg = result.encode()
        self.clientSocket.send(serverMsg)
        clientMsg = self.clientSocket.recv(1024).decode()
        message = check_role(clientMsg)
        serverMsg = message.encode()

        self.clientSocket.send(serverMsg)
        clientMsg = self.clientSocket.recv(1024).decode()   # order;discountcode;username;order1;order2...
        update_file(clientMsg)

        self.clientSocket.send(serverMsg)
        print("Disconnected from ", self.clientAddress)
        self.clientSocket.close()


def check_role(clientMsg):
    f = open("users.txt", "r")
    user1 = f.readline()
    user2 = f.readline()
    user3 = f.readline()
    f.close()

    L1 = user1.split(';')
    L2 = user2.split(';')
    L3 = user3.split(';')

    userInfo = clientMsg.split(';')
    username = userInfo[1]

    if username == L1[0]:
            role = L1[2].rstrip(L1[2][-1])
            result = username + ";" + role
            return str(result)
    elif username == L2[0]:
            role = L2[2].rstrip(L2[2][-1])
            result = username + ";" + role
            return str(result)
    elif username == L3[0]:
            role = L3[2].rstrip(L3[2][-1])
            result = username + ";" + role
            return str(result)


def check_login(clientMsg):
    f = open("users.txt", "r")
    user1 = f.readline()
    user2 = f.readline()
    user3 = f.readline()
    f.close()

    L1 = user1.split(';')
    L2 = user2.split(';')
    L3 = user3.split(';')

    userInfo = clientMsg.split(';')
    username = userInfo[1]
    password = userInfo[2]

    if username == L1[0]:
        if password == L1[1]:
            return str("login successful")
        else:
            return str("login failed")
    elif username == L2[0]:
        if password == L2[1]:
            return str("login successful")
        else:
            return str("login failed")
    elif username == L3[0]:
        if password == L3[1]:
            return str("login failed")
        else:
            return str("login failed")
    else:
        return str("login failed")


def find_totalPrice(clientMsg):         # clientMsg is in the format of discountcode;username;order1;order2;...
    updatedMsg = clientMsg.rstrip(clientMsg[-1])
    discountCode = updatedMsg.split(";")[0]
    orders = updatedMsg.split(";", 2)[2]  # creates a string with only orders included to calculate the total price easily.
    order = orders.split(";")
    order_count = len(order)  # the number of orders given for this particular order

    items = []  # the name of the orders list
    counts = []  # the counts of the orders list (how many of them is ordered)
    for item in order:
        splitted = item.split("-")
        items.append(splitted[0])
        counts.append(splitted[1])

    f = open("prices.txt", "r")
    totalprice = 0
    counter = 0
    for item in items:
        for line in range(0, 7):
            line = f.readline()
            component = line.split(";")[0]
            price = line.split(";", 1)[1]
            if component == item:
                totalprice += (int(counts[counter]) * int(price))
                break;
        counter += 1

    discountAmount = discount(discountCode)
    totalprice = totalprice - (totalprice*discountAmount)/100

    return int(totalprice)


def discount(code):
    f = open("discountcodes.txt", "r")
    i = 0
    match = 0
    if code == "nodiscountcode":
        discountAmount = 0
        match = 1
    else:
        for line in range(0,4):
            line = f.readline()
            line_splitted = line.split(";")
            if code == line_splitted[0]:
                discountAmount = int(line_splitted[1])
                match = 1
                break;
    if match!=1:        # here it checks if an invalid discount code is entered by checking the match value at the
                                # end of the file reading process
        discountAmount = 0
        print("Discount code entered is invalid! No discount applied to your order.")

    return discountAmount



def update_file(clientMsg):     # clientMsg is in the format of order;discountcode;username;order1;order2;...
    clientMsg = clientMsg.split(";", 1)[1]
    L = clientMsg.split(";")
    rest = clientMsg.split(";", 1)[1]
    rest = rest.rstrip(rest[-1])
    totalprice = find_totalPrice(clientMsg)
    lineCounter = 0
    List = []
    discountList = []

    for line in open('discountcodes.txt', 'r'):
        List.append(line)
        lineCounter = lineCounter + 1

    for c in range(lineCounter):
        discountList.append(List[c].split(";"))

    i = 0
    checker = 0
    if (L[0] == "nodiscountcode"):
        discountAmount = "0"
        checker = 1
    else:
        for i in range(lineCounter):
            if (L[0] == discountList[i][0]):
                discountAmount = discountList[i][1].rstrip(discountList[i][1][-1])
                checker = 1
                break;
    if checker != 1:
        discountAmount = "0"
        print("ayoooo\n")
        print("Discount code entered is invalid! No discount applied to your order.")

    outStr = str(totalprice) + ";" + discountAmount + ";" + rest
    print(outStr)

    f = open('orders.txt','a')
    f.write(outStr)
    f.write("\n")



HOST = "127.0.0.1"
PORT = 5000

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server.bind((HOST, PORT))
print("Server started")
print("Waiting for connection requests")

while True:
    server.listen()
    clientSocket, clientAddress = server.accept()

    newThread = ClientThread(clientSocket, clientAddress)
    newThread.start()
