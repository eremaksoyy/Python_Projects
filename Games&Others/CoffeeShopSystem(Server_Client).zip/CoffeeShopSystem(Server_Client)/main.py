
def find_totalPrice(clientMsg):
    updatedMsg = clientMsg.split(";", 1)[1]  # removes the order; part from the string
    print(updatedMsg)
    discountCode = updatedMsg.split(";")[0]
    orders = updatedMsg.split(";", 2)[2]  # creates a string with only orders included to calculate the total price easily.
    order = orders.split(";")
    order_count = len(order)  # the number of orders given for this particular order

    items = []  # the name of the orders list
    counts = []  # the counts of the orders list (how many of them is ordered)
    for item in order:
        splitted = item.split("-")
        items.append(splitted[0])
        counts.append(splitted[1])

    f = open("prices.txt", "r")
    totalprice = 0
    counter = 0
    for item in items:
        for line in range(0, 7):
            line = f.readline()
            component = line.split(";")[0]
            price = line.split(";", 1)[1]
            if component == item:
                totalprice += (int(counts[counter]) * int(price))
                break;
            counter += 1

    discountAmount = discount(discountCode)
    totalprice = totalprice - (totalprice * discountAmount) / 100

    return int(totalprice)


#find_totalPrice("order;abcd;greg;cappuccino-1;americano-1;sansebastian-1")


def discount(code):
    f = open("discountcodes.txt", "r")
    i = 0
    match = 0
    if code == "nodiscountcode":
        discountAmount = 0
    else:
        for line in range(0,4):
            line = f.readline()
            line_splitted = line.split(";")
            if code == line_splitted[0]:
                discountAmount = int(line_splitted[1])
                match = 1
                break;
        if match!=1:        # here it checks if an invalid discount code is entered by checking the match value at the
                            # end of the file reading process
            discountAmount = 0
            print("Discount code entered is invalid! No discount applied to your order.")

    return discountAmount

#c = discount("absgst")
#print(c)




def update_file(clientMsg):
    clientMsg = clientMsg.split(";", 1)[1]
    L = clientMsg.split(";")
    rest = clientMsg.split(";", 2)[2]
    totalprice = find_totalPrice("order;" + clientMsg)
    lineCounter = 0
    List = []
    discountList = []

    for line in open('discountcodes.txt', 'r'):
        List.append(line)
        lineCounter = lineCounter + 1

    for c in range(lineCounter):
        discountList.append(List[c].split(";"))

    i = 0
    checker = 0
    if(L[0] == "nodiscountcode"):
        discountAmount = "0"
        checker=1
    else:
        for i in range(lineCounter):
            if(L[0] == discountList[i][0]):
                discountAmount = discountList[i][1].rstrip(discountList[i][1][-1])
                checker = 1
                break;
    if checker!=1:  # here it checks if an invalid discount code is entered by checking the match value at the
                            # end of the file reading process
        discountAmount = "0"
        print("Discount code entered is invalid! No discount applied to your order.")

    outStr = str(totalprice) + ";" + discountAmount + ";" + rest
    print(outStr)
    f = open('orders.txt','a')
    f.write(outStr)
    f.write("\n")

update_file("order;nodiscountcode;greg;cappuccino-1;americano-1;sansebastian-1")
