This mini project will create six turtles in different colors (pre-defined colors, can be changed) and there will be a competition between those turtles. 
The user is asked to enter a color that they think is the color of the turtle who will win the race. A message will be displayed after the race stating if 
the user's guess was correct or not about the winner. The Random library is used. 