This is a Flash Card project where use can use to practice French-English vocabulary. One side of the cards will have 
the French words and the back of them will have their English version. The user can use the cross or check mark shaped 
buttons to skip the cards having the French version of the vocabulary, otherwise the cards will be flipped after some 
certain time to show the English version. If user knows the word already, they can click the check mark button but if they do 
not, then cross button needs to be clicked so the file called 'words_to_learn.csv' will be created and the words crossed will 
be added to the file. Tkinter, Random and Pandas are used.