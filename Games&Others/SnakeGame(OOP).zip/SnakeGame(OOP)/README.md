This Snake Game works same as the original snake game. There will be food that the snake needs to eat to grow and it should 
avoid touching its tail/body when it gets longer and the edges of the frame, otherwise it is game over. The user will direction
the snake by using the keyboard (up, down, right, left arrows). The game will store/show both the current and high score 
recorded, and it will be updated after every win/lose. The score (high score) will be saved to the 'data.txt' file. 
The OOP paradigm, and Time, Snake and Food libraries are used here.