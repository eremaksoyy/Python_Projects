This mini project takes an image chosen from the internet. Takes all the colors in that image, and uses those pixels to 
recreate a graphics with random dots of those colors in a random order. Dot number is user defined so it can be changed 
accordingly. Tkinter library is used here. 