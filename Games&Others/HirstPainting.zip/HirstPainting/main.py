import turtle as turtle_module
#import colorgram
import random

#rgb_colors = []
#colors = colorgram.extract('image.jpg', 30)

# or color in colors:
#r = color.rgb.r
#g = color.rgb.g
#b = color.rgb.b
#new_color = (r, g, b)
#rgb_colors.append(new_color)

#print(rgb_colors)

turtle_module.colormode(255)
tim = turtle_module.Turtle()
tim.speed("fastest")
tim.penup()
tim.hideturtle()

# getting the pixels in (r,g,b) format from the above code and create a list with those values and then comment the
# above code, except the libraries, to proceed with the code below.
color_list = [(234, 251, 243), (197, 13, 32), (249, 237, 21), (40, 76, 188), (39, 216, 69),
              (238, 227, 5), (228, 160, 48), (244, 247, 253), (28, 40, 155), (213, 75, 13), (16, 153, 16),
              (198, 15, 11), (242, 34, 163), (226, 19, 121), (75, 9, 31), (59, 15, 9), (224, 141, 208), (11, 97, 62),
              (220, 158, 10), (18, 18, 42), (49, 212, 232), (238, 156, 218), (11, 228, 239), (80, 74, 213),
              (75, 211, 166), (83, 234, 199), (58, 232, 241), (5, 67, 42)]

tim.setheading(225)
tim.forward(300)
tim.setheading(0)
number_of_dots = 100

for dot_count in range(1, number_of_dots + 1):
    tim.dot(20, random.choice(color_list))
    tim.forward(50)

    if dot_count % 10 == 0:
        tim.setheading(90)
        tim.forward(50)
        tim.setheading(180)
        tim.forward(500)
        tim.setheading(0)

screen = turtle_module.Screen()
screen.exitonclick()

