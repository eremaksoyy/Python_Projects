This Pong Game works almost as same as the original one. It is a 2-player game where one of the players use the arrows in
 the keyboard and the other one uses "w" and "s" to move the paddle. The paddles need to touch the ball to score, so players 
need to move their paddles accordingly by watching the direction of the ball. The speed of the ball increases after every bounce
and the score is displayed if any of the users lose (miss the ball). 
Turtle, Time, Paddle and Ball libraries, and OOP paradigm are used.