This Pomodoro Timer project starts counting down from 25 minutes for every working session when the user clicks the 
'start' button, and resets the timer by clicking the 'reset' button. 5 minutes break will automatically start after every 
25 minute working session, and the user can pause the timing if they wish. To be more clear if it is a break or working 
countdown on the screen, 'Break' or 'Work' messages will be shown at the screen during the corresponding activity.
Tkinter and Math are used.