Description of the program:
The code files for both tasks apply different provided algorithms to a maze to find the cheapest path from starting point to the 
goal point. The algorithms used for Task 1 are UCS (Uniform Cost Search) and A*. 
For Task 2, UCS, (BFS) Breadth-First Search, and A* are applied. 

For Task 1, UCS and A* are applied here, and the code explains how to do the necessary calculations in detail. 
As a data structure, dictionaries are used to represent the treasure map and the heuristic function.

For Task 2, three classes represent the maze, the maze graph, and the search algorithm. 
The class Maze has functions to read the maze from a file, find the start and end positions of the maze and create the string 
representation of it for further use. Class MazeGraph has the function to construct a graph from the string representation 
previously created. The SearchAlgorithm class has functions to calculate the Manhattan distance and apply the required 
algorithms, which are UCS, BFS, and A*. The networkx package, heapq module, and deque from the collections module 
(for queue operations-push&pop) are imported for this part.

How to compile and run the code:
For Task 1, the user does not need to enter any input, it can directly be run after installing the packages/modules used.
For Task 2, the name of the maze file is required as an input. Then it can be run after installing the modules. The inputs 
for this part are testcase1.txt and testcase2.txt, provided in the project folder.