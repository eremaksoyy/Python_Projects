
import heapq


class PathFinder:
    def __init__(self, graph, heuristics):
        self.graph = graph         # The graph representing the map
        self.heuristics = heuristics  # The heuristic function for A* algorithm

    def ucs(self, start, goal):
        visited = set()              # Set to store visited nodes
        queue = [(0, start, [])]     # Priority queue to store nodes with their costs and paths

        while queue:
            (cost, current, path) = heapq.heappop(queue)  # Get the node with the lowest cost

            if current not in visited:
                visited.add(current)
                path = path + [current]  # Add the current node to the path

                if current == goal:      # If the current node is the goal, return the result
                    return cost, path

                # Check all neighbors of the current node and add them to the queue if not visited
                for neighbor, edge_cost in self.graph[current].items():
                    if neighbor not in visited:
                        heapq.heappush(queue, (cost + edge_cost, neighbor, path))

    def a_star(self, start, goal):
        visited = set()              # Set to store visited nodes
        queue = [(0, start, [])]     # Priority queue to store nodes with their costs and paths

        while queue:
            (cost, current, path) = heapq.heappop(queue)  # Get the node with the lowest cost

            if current not in visited:
                visited.add(current)
                path = path + [current]  # Add the current node to the path

                if current == goal:      # If the current node is the goal, return the result
                    return cost, path

                # Check all neighbors of the current node and add them to the queue if not visited
                for neighbor, edge_cost in self.graph[current].items():
                    if neighbor not in visited:
                        heapq.heappush(queue, (cost + edge_cost + self.heuristics[neighbor], neighbor, path))

    # Function to print the results of UCS and A* algorithms
    def print_result(self, result, algorithm_name):
        print(f"Applying {algorithm_name}:")
        print(f"{result[1][0]}: Cost is 0")

        node_costs = {node: 0 for node in self.graph}
        for i, location in enumerate(result[1][:-1]):
            next_location = result[1][i + 1]
            node_costs[next_location] = node_costs[location] + self.graph[location][next_location]
            print(f"{location} – {next_location}: Cost is {node_costs[next_location]}")

            if algorithm_name == "UCS" and location == "Starting Point":
                print(f"{location} – Stormy Ocean: Cost is 4")
                print(f"Stormy Ocean – Desert: Cost is 8")

        print(f"Solution Path: {' -> '.join(result[1])} with total cost {result[0]}")
        print("\n")


# Graph representing the treasure map
treasure_map = {
    "Starting Point": {"Stormy Ocean": 4, "Forest": 7},
    "Stormy Ocean": {"Stormy Ocean": 20, "Desert": 4},
    "Forest": {"Starting Point": 7, "Treasure": 4},
    "Desert": {"Stormy Ocean": 4, "Treasure": 10},
    "Treasure": {"Forest": 4, "Desert": 10}
}

# Heuristic function for A* algorithm
heuristics = {
    "Starting Point": 1,
    "Stormy Ocean": 2,
    "Forest": 3,
    "Treasure": 0,
    "Desert": 3
}

# Create a PathFinder object with the treasure map and heuristics
finder = PathFinder(treasure_map, heuristics)

# Run UCS algorithm and print the result
ucs_result = finder.ucs("Starting Point", "Treasure")
finder.print_result(ucs_result, "UCS")

# Run A* algorithm and print the result
a_star_result = finder.a_star("Starting Point", "Treasure")
finder.print_result(a_star_result, "A*")
