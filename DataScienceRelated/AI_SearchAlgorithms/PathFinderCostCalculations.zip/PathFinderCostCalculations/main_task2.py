
import networkx as nx
import heapq
from collections import deque


class Maze:
    def __init__(self, filename):
        self.maze = self.read_maze(filename)
        self.start, self.goal = self.find_start_goal()

    # Read the maze from a file and return it as a 2D list
    def read_maze(self, filename):
        with open(filename, 'r') as file:
            maze = [list(line.strip()) for line in file.readlines()]
        return maze

    # Find the start and goal positions in the maze
    def find_start_goal(self):
        for row in range(len(self.maze)):
            for col in range(len(self.maze[0])):
                if self.maze[row][col] == 'S':
                    start = (row, col)
                elif self.maze[row][col] == 'F':
                    goal = (row, col)
        return start, goal

    # String representation of the maze
    def __str__(self):
        return "\n".join(["".join(row) for row in self.maze])


class MazeGraph:
    def __init__(self, maze):
        self.graph = self.create_graph(maze)

    # Create a graph representation of the maze
    def create_graph(self, maze):
        graph = nx.Graph()
        rows = len(maze)
        columns = len(maze[0])

        # Add nodes and edges to the graph based on open paths in the maze
        for r in range(rows):
            for c in range(columns):
                if maze[r][c] != '#':
                    node = (r, c)
                    graph.add_node(node)

                    if c > 0 and maze[r][c - 1] != '#':
                        graph.add_edge(node, (r, c - 1))

                    if r > 0 and maze[r - 1][c] != '#':
                        graph.add_edge(node, (r - 1, c))

        return graph


class SearchAlgorithm:
    # Calculate the Manhattan distance between two points
    @staticmethod
    def manhattan_distance(a, b):
        return abs(a[0] - b[0]) + abs(a[1] - b[1])

    # Perform a Uniform Cost Search on the graph and return the cost and path to the goal
    def uniform_cost_search(self, graph, start, goal):
        visited = set()
        queue = [(0, start, [])]

        while queue:
            cost, current, path = heapq.heappop(queue)
            if current not in visited:
                visited.add(current)
                path = path + [current]

                if current == goal:
                    return cost, path

                for neighbor in graph.neighbors(current):
                    heapq.heappush(queue, (cost + 1, neighbor, path))

        return None, None

    # Perform a Breadth-First Search on the graph and return the cost and path to the goal
    def breadth_first_search(self, graph, start, goal):
        visited = set()
        queue = deque([(start, [])])

        while queue:
            current, path = queue.popleft()
            if current not in visited:
                visited.add(current)
                path = path + [current]

                if current == goal:
                    return len(path) - 1, path

                for neighbor in graph.neighbors(current):
                    queue.append((neighbor, path))

        return None, None

    # Perform an A* Search on the graph and return the cost and path to the goal
    def a_star_search(self, graph, start, goal):
        visited = set()
        queue = [(0, start, [])]

        while queue:
            cost, current, path = heapq.heappop(queue)
            if current not in visited:
                visited.add(current)
                path = path + [current]

                if current == goal:
                    return cost, path

                for neighbor in graph.neighbors(current):
                    heuristic_cost = self.manhattan_distance(neighbor, goal)
                    heapq.heappush(queue, (cost + 1 + heuristic_cost, neighbor, path))

        return None, None


def main():
    filename = input("Enter the maze file name: ")
    maze = Maze(filename)
    graph = MazeGraph(maze.maze)

    print("Start:", maze.start)
    print("Goal:", maze.goal)

    search = SearchAlgorithm()

    # Perform searches
    ucs_cost, ucs_path = search.uniform_cost_search(graph.graph, maze.start, maze.goal)
    bfs_cost, bfs_path = search.breadth_first_search(graph.graph, maze.start, maze.goal)
    astar_cost, astar_path = search.a_star_search(graph.graph, maze.start, maze.goal)

    # Print the results
    print("\nMaze:")
    print(maze)

    print("\nShortest Path (UCS):")
    print(f"Cost: {ucs_cost}")
    print(f"Path: {ucs_path}")

    print("\nShortest Path (BFS):")
    print(f"Cost: {bfs_cost}")
    print(f"Path: {bfs_path}")

    print("\nShortest Path (A*):")
    print(f"Cost: {astar_cost}")
    print(f"Path: {astar_path}")


if __name__ == "__main__":
    main()


