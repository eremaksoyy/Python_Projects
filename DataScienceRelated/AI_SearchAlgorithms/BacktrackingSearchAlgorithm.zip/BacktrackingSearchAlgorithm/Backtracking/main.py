
# defining the problem & dictionaries
time_slots = ['10 AM', '11 AM', '12 PM', '1 PM']
speakers = {
    'T': {'time': ['10 AM'], 'groups': ['Aerospace']},
    'L': {'time': time_slots, 'groups': ['MATH', 'Society of Women Engineers', 'Aerospace']},
    'B': {'time': time_slots, 'groups': ['PHY']},
    'C': {'time': time_slots, 'groups': ['PHY', 'Society of Women Engineers']},
    'S': {'time': time_slots, 'groups': ['AI']},
    'P': {'time': time_slots, 'groups': ['MATH', 'AI']},
    'N': {'time': time_slots, 'groups': ['PHY', 'MATH', 'Aerospace']}
}

groups = {
    'PHY': ['B', 'C', 'N'],
    'MATH': ['L', 'P', 'N'],
    'AI': ['S', 'P'],
    'Society of Women Engineers': ['L', 'C'],
    'Aerospace': ['T', 'L', 'N']
}

def is_complete(schedule):
    return set(schedule.keys()) == set(speakers.keys())


# returning to an unassigned speaker to assign a time slot to it
def select_unassigned_speaker(schedule):
    unassigned_speakers = [speaker for speaker in speakers if speaker not in schedule]
    return min(unassigned_speakers, key=lambda speaker: len(speakers[speaker]['time']))


# checking the time slots if there is any unwanted clashes 
def is_consistent(speaker, time_slot, schedule):
    for other_speaker, other_time_slot in schedule.items():
        if other_time_slot == time_slot and any(group in speakers[speaker]['groups'] for group in speakers[other_speaker]['groups']):
            return False
    return True


##choice 1 pure backtracking 
def backtrack(schedule, history):
    if is_complete(schedule):
        return schedule, history
    speaker = select_unassigned_speaker(schedule)
    for time_slot in speakers[speaker]['time']:
        if is_consistent(speaker, time_slot, schedule): # if there is no clash, assign the slot for the speaker
            schedule[speaker] = time_slot
            history.append((speaker, time_slot))    # keeping track of the speakers and their assigned time slots
            result, history = backtrack(schedule, history)  # apply the algo selected 
            if result is not None:
                return result, history
            del schedule[speaker]
            history.pop()
    return None, history


## choice 2 backtracking with forward check
def backtrack_with_forward_checking(schedule, history):
    if is_complete(schedule):
        return schedule, history
    speaker = select_unassigned_speaker(schedule)
    for time_slot in speakers[speaker]['time']:
        if is_consistent(speaker, time_slot, schedule):
            schedule[speaker] = time_slot
            history.append((speaker, time_slot))
            if not backtrack_with_forward_checking(schedule, history):  # doing the forward check here, the rest is the same as pure backtracking 
                del schedule[speaker]
                history.pop()
                continue
            result, history = backtrack_with_forward_checking(schedule, history)
            if result is not None:
                return result, history
            del schedule[speaker]
            history.pop()
    return None, history


##choice 3 backtracking with arc consistency
def arc_consistency():
    queue = [(X, Y) for X in speakers for Y in speakers if X != Y]
    while queue:
        X, Y = queue.pop(0)
        # checking after each change to eliminate the inconsistent values
        if remove_inconsistent_values(X, Y):    
            for Z in [Z for Z in speakers if Z != X and Z != Y]:
                queue.append((Z, X))


# removing the inconsistent values according to the constraints 
def remove_inconsistent_values(X, Y):
    removed = False
    for x in speakers[X]['time']:
        if not any(is_consistent(X, x, {Y: y}) for y in speakers[Y]['time']):
            speakers[X]['time'].remove(x)
            removed = True
    return removed


##choice 4 backtracking with degree heuristic
def degree_heuristic(speaker):  # calculating the heuristic value based on the length
    return len(speakers[speaker]['groups'])

# picking an unassigned speaker for the degree heuristic
def select_unassigned_speaker_degree_heuristic(schedule):
    unassigned_speakers = [speaker for speaker in speakers if speaker not in schedule]
    return max(unassigned_speakers, key=degree_heuristic)

def backtrack_with_degree_heuristic(schedule, history):
    if is_complete(schedule):
        return schedule, history
    speaker = select_unassigned_speaker_degree_heuristic(schedule)
    for time_slot in speakers[speaker]['time']:
        if is_consistent(speaker, time_slot, schedule):
            schedule[speaker] = time_slot
            history.append((speaker, time_slot))
            result, history = backtrack_with_degree_heuristic(schedule, history)    # applying the algo for all speakers
            if result is not None:
                return result, history
            del schedule[speaker]
            history.pop()
    return None, history


## choice 5 backtracking with MRV
def backtrack_with_MRV(schedule, history):
    if is_complete(schedule):
        return schedule, history
    speaker = select_unassigned_speaker(schedule)
    for time_slot in speakers[speaker]['time']:
        if is_consistent(speaker, time_slot, schedule):
            schedule[speaker] = time_slot
            history.append((speaker, time_slot))
            result, history = backtrack_with_MRV(schedule, history)     # applying the algo for all speakers
            if result is not None:
                return result, history
            del schedule[speaker]
            history.pop()
    return None, history


## choice 6 backtracking with min conflict
# calculating the conflicts for all
def min_conflicts(speaker, schedule):
    conflicts = 0
    for other_speaker, other_time_slot in schedule.items():
        if any(group in speakers[speaker]['groups'] for group in speakers[other_speaker]['groups']):
            conflicts += 1
    return conflicts


# picking an unassigned speaker for the min conflicts
def select_unassigned_speaker_min_conflicts(schedule):
    unassigned_speakers = [speaker for speaker in speakers if speaker not in schedule]
    return min(unassigned_speakers, key=lambda speaker: min_conflicts(speaker, schedule))


# applyting backtracking with min-conflict
def backtrack_min_conflict(schedule, history):
    if is_complete(schedule):
        return schedule, history
    speaker = select_unassigned_speaker_min_conflicts(schedule) # selecting the speaker
    for time_slot in speakers[speaker]['time']:
        if is_consistent(speaker, time_slot, schedule):
            schedule[speaker] = time_slot
            history.append((speaker, time_slot))
            result, history = backtrack_min_conflict(schedule, history) # applying the algo for all speakers
            if result is not None:
                return result, history
            del schedule[speaker]
            history.pop()
    return None, history


# function to display the results based on user's selection
def print_result(result, history):
    if result is None:
        print("No valid schedule found.")
    else:
        cumulative_schedule = {}
        for step, (speaker, time_slot) in enumerate(history, 1):
            cumulative_schedule[speaker] = time_slot
            assignments = ', '.join(f"{s} is scheduled at {t}" for s, t in cumulative_schedule.items())
            print(f"Step {step}: {assignments}")


# main function
def main():
    # printing the menu
    print("--------------------------------- METU Time Machine Scheduler --------------------------")
    print("Select the scheduling technique:")
    print("1. Pure backtracking search algorithm")
    print("2. Backtracking search algorithm + forward checking")
    print("3. Backtracking search algorithm + Arc Consistency")
    print("4. Backtracking search algorithm + Degree Heuristic")
    print("5. Backtracking search algorithm + MRV")
    print("6. Backtracking search algorithm + Min- Conflict")
    print("7. Exit")
    print("---------------------------------------------------------------------------------------------------")

    # getting the user's choice
    choice = int(input("Your choice: "))

    # initializing an empty schedule and history
    schedule = {}
    history = []

    # applying the selected algorithms

    if choice == 1:
        result, history = backtrack(schedule, history)
    elif choice == 2:
        result, history = backtrack_with_forward_checking(schedule, history)
    elif choice == 3:
        arc_consistency()
        result, history = backtrack({}, [])
    elif choice == 4:
        result, history = backtrack_with_degree_heuristic({}, [])
    elif choice == 5:
        result, history = backtrack_with_MRV({}, [])
    elif choice == 6:
        result, history = backtrack_min_conflict({}, [])
    elif choice == 7:
        return
    else:
        print("Invalid choice.")
        return

    # printing the result
    print_result(result, history)


# main function call
if __name__ == "__main__":
    main()
