This project is a Time Machine Schedular. Using set of values to arrange a meeting, several methods are 
used to apply the algorithm. 

The algorithms used are listed as:
   - Pure Backtracking search algorithm  
   - Backtracking search algorithm with Forward Checking 
   - Backtracking search algorithm with Arc Consistency 
   - Backtracking search algorithm with Degree Heuristic 
   - Backtracking search algorithm with MRV
   - Backtracking search algorithm with Min-Conflict

The variables and the constraints are NOT taken from the user, they are pre-defined in the code.
Dictionaries are used as a data structure.