This project is a Time Machine Schedular. Using set of values to arrange a meeting, several methods are 
used to apply the algorithm. 

The algorithms used are listed as:
   - Pure Backtracking search algorithm  
   - Backtracking search algorithm with Forward Checking 
   - Backtracking search algorithm with Arc Consistency 
   - Backtracking search algorithm with Degree Heuristic 
   - Backtracking search algorithm with MRV (Minimum Remaining Value) Heuristic
   - Backtracking search algorithm with Min-Conflict Heuristic

The variables and the constraints are taken from the user, they are NOT pre-defined in the code. 