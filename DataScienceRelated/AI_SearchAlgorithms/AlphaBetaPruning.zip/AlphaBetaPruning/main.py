import math
import random

# Define the Game class
class Game:
    def __init__(self, size=7):
        self.size = size  # Size of the board
        self.empty = '-'  # Empty cell symbol
        self.board = [[self.empty] * size for _ in range(size)]  # Initialize the board
        self.playerSymbol = None  # Player's symbol (X or O)
        self.computerSymbol = None  # Computer's symbol (X or O)

    # Display the current state of the board
    def display(self):
        for row in self.board:
            print(' '.join(row))
        print()

    # Check if the game is over (either player has won or the board is full)
    def is_over(self):
        # Check rows
        for row in self.board:
            for col in range(self.size - 3):
                if row[col] == row[col + 1] == row[col + 2] == row[col + 3] != self.empty:
                    return True

        # Check columns
        for col in range(self.size):
            for row in range(self.size - 3):
                if self.board[row][col] == self.board[row + 1][col] == self.board[row + 2][col] == self.board[row + 3][
                    col] != self.empty:
                    return True

        # Check diagonals
        for row in range(self.size - 3):
            for col in range(self.size - 3):
                if self.board[row][col] == self.board[row + 1][col + 1] == self.board[row + 2][col + 2] == \
                        self.board[row + 3][col + 3] != self.empty:
                    return True
        for row in range(3, self.size):
            for col in range(self.size - 3):
                if self.board[row][col] == self.board[row - 1][col + 1] == self.board[row - 2][col + 2] == \
                        self.board[row - 3][col + 3] != self.empty:
                    return True

        return False

    # Make a move on the board
    def make_move(self, move, symbol):
        row, col = move
        self.board[row][col] = symbol

    # Get all possible moves (empty cells)
    def get_moves(self):
        moves = []
        for row in range(self.size):
            for col in range(self.size):
                if self.board[row][col] == self.empty:
                    moves.append((row, col))
        return moves

    # Evaluate the board (1 if computer wins, -1 if player wins, 0 otherwise)
    def get_score(self):
        for row in self.board:
            for col in range(self.size - 3):
                if row[col] == row[col + 1] == row[col + 2] == row[col + 3] == self.playerSymbol:
                    return 1
                if row[col] == row[col + 1] == row[col + 2] == row[col + 3] == self.computerSymbol:
                    return -1
        for col in range(self.size):
            for row in range(self.size - 3):
                if self.board[row][col] == self.board[row + 1][col] == self.board[row + 2][col] == self.board[row + 3][
                    col] == self.playerSymbol:
                    return 1
                if self.board[row][col] == self.board[row + 1][col] == self.board[row + 2][col] == self.board[row + 3][
                    col] == self.computerSymbol:
                    return -1
        for row in range(self.size - 3):
            for col in range(self.size - 3):
                if self.board[row][col] == self.board[row + 1][col + 1] == self.board[row + 2][col + 2] == \
                        self.board[row + 3][col + 3] == self.playerSymbol:
                    return 1
                if self.board[row][col] == self.board[row + 1][col + 1] == self.board[row + 2][col + 2] == \
                        self.board[row + 3][col + 3] == self.computerSymbol:
                    return -1
        return 0


# Define the Player class (represents the computer player)
class Player:
    def __init__(self, game):
        self.game = game  # Game instance

    # Alpha-beta pruning algorithm to find the best move
    def alpha_beta(self, depth, maximizing_player, alpha=-math.inf, beta=math.inf):
        if depth == 0 or self.game.is_over():
            return self.game.get_score()

        if maximizing_player:
            maxVal = -math.inf
            for move in self.game.get_moves():
                self.game.make_move(move, self.game.playerSymbol)
                val = self.alpha_beta(depth - 1, False, alpha, beta)
                self.game.make_move(move, self.game.empty)
                maxVal = max(maxVal, val)
                alpha = max(alpha, val)
                if alpha >= beta:
                    break
            return maxVal
        else:
            minVal = math.inf
            for move in self.game.get_moves():
                self.game.make_move(move, self.game.computerSymbol)
                val = self.alpha_beta(depth - 1, True, alpha, beta)
                self.game.make_move(move, self.game.empty)
                minVal = min(minVal, val)
                beta = min(beta, val)
                if beta <= alpha:
                    break
            return minVal

    # Get the best move for the computer player
    def get_best_move(self, depth=5):
        bestMove, maxVal = None, -math.inf

        for move in self.game.get_moves():
            self.game.make_move(move, self.game.playerSymbol)
            val = self.alpha_beta(depth - 1, False)
            self.game.make_move(move, self.game.empty)

            if val > maxVal:
                maxVal, bestMove = val, move

        return bestMove

# Main function to run the game
def main():
    game = Game()  # Create a new game
    player = Player(game)  # Create a new player (computer)

    # Ask the human player to choose a symbol
    game.playerSymbol = input("Please pick your symbol (X/O): ").upper()

    while game.playerSymbol not in ['X', 'O']:
        game.playerSymbol = input("Invalid symbol. Please pick your symbol again (X/O): ").upper()

    game.computerSymbol = 'O' if game.playerSymbol == 'X' else 'X'

    game.display()  # Display the initial state of the board

    # Game loop
    while not game.is_over():
        # Ask the human player to make a move
        move = tuple(map(int, input("Enter your move in (row column) format [from 0 0 -> 6 6]: ").split()))

        # Check if the move is valid
        while game.board[move[0]][move[1]] != game.empty:
            print("Invalid move, try again!")
            move = tuple(map(int, input("Enter your move in (row column) format [from 0 0 -> 6 6]: ").split()))

        game.make_move(move, game.playerSymbol)  # Make the move
        game.display()  # Display the board after the move

        if game.is_over():
            break

        print("Computer's Turn")
        move = player.get_best_move()  # Get the best move for the computer
        game.make_move(move, game.computerSymbol)  # Make the move
        game.display()  # Display the board after the move

    # Display the result of the game
    score = game.get_score()

    if score == 1:
        print("\n You win! \n")
    elif score == -1:
        print("\n Computer wins! \n")
    else:
        print("\n It's a tie! \n")

if __name__ == '__main__':
    main()  # Run the game
