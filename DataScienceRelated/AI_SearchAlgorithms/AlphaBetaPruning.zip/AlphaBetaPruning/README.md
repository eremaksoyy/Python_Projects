This project is a 2-player Tic Tac Toe game. It applies Alpha Beta pruning algorithm for the selection of computer's choice 
to calculate the best move. The user is asked to pick their symbol (X or O), and the computer gets the other symbol for the 
game. When it is user's turn, they will be asked to enter the coordinates according to the board displayed and when it is 
computer's turn, the Alpha-Beta pruning will be applied and the best move considering the current situation will be made. 
The board size is implemented to be 7x7 but any change regarding this can be easily made from the code.
Math and Random libraries are used.