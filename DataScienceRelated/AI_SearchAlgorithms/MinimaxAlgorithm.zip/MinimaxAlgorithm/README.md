This project is a 2-player Tic Tac Toe game. It applies Minimax (search) algorithm for the selection of computer's choice 
to make the best move. The user is asked to pick their symbol (X or O), and the computer gets the other symbol for the 
game. When it is user's turn, they will be asked to enter the coordinates according to the board displayed and when it is 
computer's turn, the Minimax will be applied and the best move considering the current situation will be made. The board
created for the game is set as 3D (3x3) but any modifications regarding the size can be easily made from the code.
The Math library is used.