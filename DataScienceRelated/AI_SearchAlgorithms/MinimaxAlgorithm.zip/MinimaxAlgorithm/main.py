import math

class TicTacToeGame:
    def __init__(self, board_size=3):
        self.empty_space = '-'  # Marker for empty spaces on the board
        self.board_size = board_size  # Size of the game board
        self.game_board = [[self.empty_space] * board_size for _ in range(board_size)]  # Create an empty game board
        self.player_marker = None  # Marker for the player
        self.computer_marker = None  # Marker for the computer

    def set_player_marker(self, marker):
        self.player_marker = marker
        self.computer_marker = 'O' if marker == 'X' else 'X'  # Set the computer's marker opposite to the player's

    def display_game_board(self):
        for row in self.game_board:
            print(' '.join(row))  # Print the current state of the game board

    def check_game_over(self):
        for row in self.game_board:
            if row.count(row[0]) == len(row) and row[0] != self.empty_space:
                return True  # Check rows for a winning condition

        for col in range(self.board_size):
            if len(set(row[col] for row in self.game_board)) == 1 and self.game_board[0][col] != self.empty_space:
                return True  # Check columns for a winning condition

        if all(self.game_board[i][i] == self.game_board[0][0] != self.empty_space for i in range(self.board_size)):
            return True  # Check diagonal from top-left to bottom-right for a winning condition

        if all(self.game_board[i][self.board_size - i - 1] == self.game_board[0][self.board_size - 1] != self.empty_space for i in range(self.board_size)):
            return True  # Check diagonal from top-right to bottom-left for a winning condition

        return all(self.empty_space not in row for row in self.game_board)  # Check for a tie

    def evaluate_game_board(self):
        for row in self.game_board:
            if row.count(self.player_marker) == self.board_size:
                return 1  # Player has won
            elif row.count(self.computer_marker) == self.board_size:
                return -1  # Computer has won

        for col in range(self.board_size):
            column = [row[col] for row in self.game_board]
            if column.count(self.player_marker) == self.board_size:
                return 1  # Player has won
            elif column.count(self.computer_marker) == self.board_size:
                return -1  # Computer has won

        if [self.game_board[i][i] for i in range(self.board_size)].count(self.player_marker) == self.board_size:
            return 1  # Player has won

        elif [self.game_board[i][i] for i in range(self.board_size)].count(self.computer_marker) == self.board_size:
            return -1  # Computer has won

        if [self.game_board[i][self.board_size - i - 1] for i in range(self.board_size)].count(self.player_marker) == self.board_size:
            return 1  # Player has won

        elif [self.game_board[i][self.board_size - i - 1] for i in range(self.board_size)].count(self.computer_marker) == self.board_size:
            return -1  # Computer has won

        return 0  # Game is not over yet

    def place_marker(self, move, marker):
        row, col = move
        self.game_board[row][col] = marker  # Place the specified marker at the given position

    def get_available_moves(self):
        return [(i, j) for i in range(self.board_size) for j in range(self.board_size) if self.game_board[i][j] == self.empty_space]
        # Return a list of available moves (empty spaces) on the game board

    def minimax_algorithm(self, depth, isMaximizingPlayer):
        if depth == 0 or self.check_game_over():
            return self.evaluate_game_board()  # If game is over or depth limit is reached, return the evaluation score

        if isMaximizingPlayer:
            max_evaluation = -math.inf
            for move in self.get_available_moves():
                self.place_marker(move, self.player_marker)
                evaluation = self.minimax_algorithm(depth - 1, False)
                self.place_marker(move, self.empty_space)
                max_evaluation = max(max_evaluation, evaluation)
            return max_evaluation  # Return the maximum evaluation score

        else:
            min_evaluation = math.inf
            for move in self.get_available_moves():
                self.place_marker(move, self.computer_marker)
                evaluation = self.minimax_algorithm(depth - 1, True)
                self.place_marker(move, self.empty_space)
                min_evaluation = min(min_evaluation, evaluation)
            return min_evaluation  # Return the minimum evaluation score

    def get_optimal_move(self):
        optimal_move = None
        max_evaluation = -math.inf

        for move in self.get_available_moves():
            self.place_marker(move, self.player_marker)
            evaluation = self.minimax_algorithm(5, False)
            self.place_marker(move, self.empty_space)

            if evaluation > max_evaluation:
                max_evaluation, optimal_move = evaluation, move

        return optimal_move  # Return the move with the highest evaluation score

    def player_move(self, move):
        self.place_marker(move, self.player_marker)  # Place the player's marker at the specified position

    def computer_move(self):
        move = self.get_optimal_move()
        self.place_marker(move, self.computer_marker)  # Place the computer's marker at the optimal position

def main():
    game = TicTacToeGame()

    player_marker = input("Please pick your marker (X/O): ").upper()

    while player_marker not in ['X', 'x', 'O', 'o']:
        player_marker = input("Invalid marker. Please pick your marker again (X/O): ").upper()

    game.set_player_marker(player_marker)

    game.display_game_board()

    while not game.check_game_over():
        move = tuple(map(int, input("Enter your move in (row col) format [from 0 0 -> 2 2]: ").split()))

        while game.game_board[move[0]][move[1]] != game.empty_space:
            move = tuple(map(int, input("Invalid move, try again: ").split()))

        game.player_move(move)

        if game.check_game_over():
            break

        game.computer_move()

        game.display_game_board()

    game.display_game_board()
    score = game.evaluate_game_board()

    if score == 1:
        print("================\n You win! \n================")
    elif score == -1:
        print("================\n Computer wins! \n================")
    else:
        print("================\n It's a tie! \n================")

if __name__ == '__main__':
    main()
