This notebook practices the implementations of SVD (Single Value Decomposition), and image reconstruction. 
It shows different approaches and helps with understanding the basics more deeply. 
Numpy, Scikit-learn, Scipy, and Matplotlib are used.