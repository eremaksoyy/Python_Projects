This notebook practices Gradient Descent using PyTorch. LU decomposition, QR decomposition, and 
SV decomposition of matrices using gradient descent are calculated and tested with sample matrices.