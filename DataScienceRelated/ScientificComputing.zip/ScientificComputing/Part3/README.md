This notebook practices the concepts LU decomposition, Discrete Fourier Transform (DFT), and 
Fast Fourier Transform (FFT). Random, Time, Math and CMath libraries are used.