import sqlite3
import pyAesCrypt
import datetime

def Encryption(file_name, password):
     pyAesCrypt.encryptFile(file_name, (file_name+".enc"), password)

    
def Decyrption(file_name, password):
    f_name = file_name[:-4]
    pyAesCrypt.decryptFile(file_name, f_name, password)
    
    
file_name = input("Enter file name (HW12.db.enc): ")
password=input("Enter password (strong_pass123): ")
Decyrption(file_name, password)

connection = sqlite3.connect("HW12.db")
database = connection.cursor()

choice = int(input('1. Load an existing account\n2. Create a new account\nPlease select: '))
if(choice==1):
    account_name = input("Enter the account name: ")
    print()
    database.execute("SELECT * FROM Ledgertable where AccountName='{}'".format(account_name))
    rows = database.fetchall()
    if (len(rows)==0):
        print("There is no account with the required name!")
    else:
        for row in rows:
            print("Account Name:", row[0])
            print("Account Number:", row[1])
            print("Date:", row[2])
            print("Debit:", row[3])
            print("Credit:", row[4])
            print("Debit Balance:", row[5])
            print("Credit Balance:", row[6])
    connection.commit()
    
elif(choice==2):
    debitBalance = 0;
    creditBalance = 0;
    new_account_name = input('Enter the values for the new account:\nAccount Name: ')
    account_number = int(input('Account Number: '))
    date = datetime.date.today()
    debit = float(input('Debit: '))
    credit = float(input('Credit: '))
    if(debit-credit>0):
        debitBalance = debit - credit
    else:
        creditBalance = credit - debit
    database.execute("INSERT INTO ledgertable (AccountName,AccountNumber,Date,Debit,Credit,DebitBalance,CreditBalance)  VALUES ('{}','{}','{}', {} , {}, {}, {})".format(new_account_name,account_number,date,debit,credit,debitBalance,creditBalance))
    print("New account is created successfully!")
    connection.commit()
connection.close()
    
Encryption(file_name[:-4],password)
    
    
    
