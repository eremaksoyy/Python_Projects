import pyAesCrypt

operation = int(input('1. Encryption\n2. Decryption\nPlease select an operation: '))
file_name = input('Enter file name: ')
password = input('Please enter a password: ')

if(operation == 1):
    pyAesCrypt.encryptFile(file_name+".txt", file_name+".txt.enc", password)
elif(operation == 2):
    pyAesCrypt.decryptFile(file_name+".txt.enc", file_name+"out.txt", password)
else:
    print('Invalid operation is selected! Try again!\n\n')