import sqlite3
import pyAesCrypt

connection = sqlite3.connect('HW12.db')
database = connection.cursor()

def CreateTable():
    command = "CREATE TABLE IF NOT EXISTS Ledgertable(AccountName TEXT, AccountNumber INT, Date TEXT, Debit INT, Credit INT, DebitBalance INt, CreditBalance INT)"
    database.execute(command)
    connection.commit()
    connection.close()
    
def Encryption(file_name, password):
     pyAesCrypt.encryptFile(file_name, (file_name+".enc"), password)
CreateTable()

file_name = input("Enter file name (HW12.db): ")
password = input("Enter password (strong_pass123): ")

Encryption(file_name,password)
