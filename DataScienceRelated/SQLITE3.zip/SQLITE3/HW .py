import datetime

choice = int(input('1. Load an existing account\n2. Create a new account\nPlease select: '))
if (choice == 1):
    name = input('Enter name to open the file: ')
    file = open(name + ".txt", "r+")
    print('\n') 
    rows = [row for row in file.readlines()]
    LastBalance = float(rows[-1].split("\t")[5])
    print('The last balance is: ' + str(LastBalance))
    file.write("\nLast Balance:\t\t\t\t\t" + str(LastBalance) + '\n')
    if(LastBalance > 0):
        print('This is a debit account!\n')
    else:
        print('This is a credit account!\n')
    select = int(input('1. Withdraw\n2. Deposit \nPlease select: '))
    amount = int(input('Enter the amount: '))
    if (select == 1):
        LastBalance = LastBalance - amount
        file.write("Last Balance after withdraw:   \t\t\t" + str(LastBalance) + '\n')
    elif (select == 2):
        LastBalance = LastBalance + amount
        file.write("Last Balance after deposit:   \t\t\t\t" + str(LastBalance) + '\n')
    file.close()
      
elif (choice == 2):
    name = input('Enter a name for the new account: ')
    f = open(name + ".txt", "w")
    if (f == None):
        print('Creating a new file failed!')
        exit(1)
    AccountNumber = int(input('Account Number: '))
    list = []
    list.append("AccountName\tAccountNumber\tDate\tDebit\tCredit\tDebitBalance\tCreditBalance\n")
    lines = int(input('How many rows do you want to use: '))
    DebitBalance = 0
    for x in range(lines):
        print("Line " + str(x+1) + ": ")
        AccountName = name
        Date = datetime.date.today()
        Debit = float(input('Debit: '))
        Credit = float(input('Credit: '))
        DebitBalance = DebitBalance + Debit - Credit
        list.append(str(AccountName)+"\t"+str(AccountNumber)+"\t"+str(Date)+"\t"+str(Debit)+"\t"+str(Credit)+"\t"+str(DebitBalance)+"\n")
    f.writelines(list)
    f.close()
else:
    print('Try again! Invalid option selected! \n')




