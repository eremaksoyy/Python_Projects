This folder has many projects having the implementation for Supervised Learning concept. Regression and 
classification implementations are available.

Scientific computing libraries (Numpy, Scipy, Pandas, etc.) and data visualization (matplotlib) libraries are used.
